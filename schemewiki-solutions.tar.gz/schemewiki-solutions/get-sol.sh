#!/bin/sh

for i in $(seq 1 5)
do
    for j in $(seq 1 97)
    do
        wget -q "http://community.schemewiki.org/?sicp-ex-$i.$j"
        mv "index.html?sicp-ex-$i.$j" "sicp-ex-$i-$j.html"
    done
done
